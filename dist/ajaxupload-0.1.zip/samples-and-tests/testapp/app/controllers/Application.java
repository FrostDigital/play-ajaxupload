package controllers;

import java.io.File;

import play.Logger;
import play.Play;
import play.mvc.Controller;

public class Application extends Controller {
	
	public static void index() {
		Logger.warn(params.all().toString());
        render();
    }
	
	public static void upload(File qqfile) {
		Logger.warn(qqfile + "");
		Logger.warn(Play.tmpDir.getAbsolutePath());
        Logger.warn(request.args.get("__UPLOADS").toString());
		renderText("{success:true}");
    }
	

}